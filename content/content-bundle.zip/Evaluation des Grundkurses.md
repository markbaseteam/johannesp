---
tags:
  - Evaluation
  - EJ/Grundkurs
  - EJ
---
Die #Dekanatsjugendkammer hat folgende Ziele für den Grundkurs festgelegt:
1. Befähigung zu Jugendleiter:innen
2. Persönlichkeitsentwicklung
3. Bindung an evangelische Jugendarbeit
Die Ziele sind auch in dieser Reihenfolge priorisiert bzw. untergeordnet.
## Forschungsfrage
Version 1:
> Wie effektiv fördert der Grundkurs die Befähigung angehender Jugendleiter:innen durch die Vermittlung von Fähigkeiten zur Planung, Durchführung von Jugendaktivitäten, die Anwendung pädagogischer Methoden, die Auseinandersetzung mit ethischen Fragen, die Umsetzung jugendrelevanter Themen in der praktischen Arbeit sowie die eigenständige Gestaltung der Jugendverbandsarbeit? In wie weit wird dabei, die Persönlichkeitsentwicklung der Jugendlichen und Bindung an die evangelische Jugendarbeit unterstützt.

Version 2: 
> Wie effektiv fördert der Grundkurs die Befähigung angehender Jugendleiter:innen im Bezug auf ihre Tätigkeiten in der Jugendverbandsarbeit? In wie weit wird dabei, die Persönlichkeitsentwicklung der Jugendlichen und Bindung an die evangelische Jugendarbeit unterstützt.
## Zeitplan
| Was                | Beginn     | Deadline   | Beschreibung                                                               |
| ------------------ | ---------- | ---------- | -------------------------------------------------------------------------- |
| AG zusammestellen  | 06.11.2023 | 26.11.2023 | Infotext zur Evaluations-AG wird geteilt zusammen mit einer Terminumfrage. |
| Zeitplan erstellen |            |            | Der weitere Zeitplan der Evaluation soll erstellt werden.                  |
## Inhalte / Fragestellungen
- Wo schaust Sachen bezüglich der Jugendarbeit nach? (Handbuch analog oder digital -> [[EJ-Wiki]])
- In welchen Situationen der Jugendarbeit fühlst Du Dich unsicher / kommst du nicht klar?
- Wie wirksam ist der Grundkurs bei der Vermittlung von Fähigkeiten zur Planung und Durchführung von Jugendaktivitäten?
- Welche pädagogischen Methoden werden im Grundkurs vermittelt, und wie tragen sie zur Entwicklung von pädagogischen Fertigkeiten bei?
- Inwiefern wird im Grundkurs die Auseinandersetzung mit ethischen Fragen und jugendrelevanten Themen gefördert, und inwieweit werden diese von den angehenden Jugendleiter:innen in ihrer praktischen Arbeit umgesetzt?
- In welchem Maße und in welchen weiteren Aspekten ermöglicht der Grundkurs den Teil- nehmenden, die Jugendverbandsarbeit aktiv und eigenständig zu gestalten?
- Wie viel Zeit für einzelne Inhalte verwendet und wie viel wird für eine erfolgreiche Vermittlung benötigt?
- Wie nachhaltig wirkt der Grundkurs?
## Operationalisierung
- Fähigkeiten zur Planung und Durchführung von Jugendverbandsaktivitäten
	- Kompetenzen im Bereich der Gremienarbeit
		- Wissen über Partizipationsmöglichkeiten
	- Moderationskompetenzen
	- Vorbereitungskompetenzen von Maßnahmen
		- Kalkulation von Maßnahmen
		- Planung der Verpflegung für Großgruppen
	- Durchführungskompetenzen von Maßnahmen
	- Nachbereitungskompetenzen von Maßnahmen
		- Feedback
		- Reflexionskompetenzen
		- Finanzielle Abwicklung
	- Teamfähigkeit
		- Zuverlässigkeit
		- Arbeitsteilung
		- Kompromissbereitschaft
	- Wissen über rechtlich relevante Grundlagen
		- Jugendschutzgesetz
	- Handlungsfähigkeit in Notfallsituationen
- Fähigkeit zum adäquaten pädagogischen Handeln
	- Einschätzungskompetenz von Gruppensituationen- und Dynamiken
		- Gruppenphasen
		- Gruppenrollen
	- Adäquater Einsatz von Leitungsstilen
	- Umgang mit Konflikten
	- Umgang mit Krisen
	- Bewusstsein über Vorbildfunktion
- Beurteilungskompetenz von ethisch- und wertebasierten Fragen im Sinne der Evangelischen Jugendverbandsarbeit
	- Verständnis über Kampagnen der Evangelischen Jugend
	- Sprachfähigkeit über Kampagnen der Evangelischen Jugend
	- Sprachfähigkeit im Glauben
- Aufgewendete Zeit für das Erwerben einzelner Kompetenzen
## Dokumente
[[3.9 Hausarbeit - Johannes Pauli - Selbstevaluation des Grundkurses der Evangelischen Jugend Fürstenfeldbruck .pdf]]